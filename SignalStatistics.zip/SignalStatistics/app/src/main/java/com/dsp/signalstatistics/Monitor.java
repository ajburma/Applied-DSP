package com.dsp.signalstatistics;

public interface Monitor {
	public void notify(String message);
}
